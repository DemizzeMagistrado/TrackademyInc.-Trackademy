import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'add_category_page.dart';
import 'summary_wheel.dart';

class FinancePage extends StatefulWidget {
  final double monthlyLimit;
  final String selectedMonth;

  const FinancePage({
    Key? key,
    required this.monthlyLimit,
    required this.selectedMonth,
  }) : super(key: key);

  @override
  _FinancePageState createState() => _FinancePageState();
}

class _FinancePageState extends State<FinancePage> {
  double currentSpent = 0.0;
  bool hasShownLimitWarning = false;

  List<Map<String, dynamic>> expenseCategories = [];
  int _selectedIndex = 2;

  double get totalSpent {
    double total = 0;
    for (var category in expenseCategories) {
      if (category['amount'] != null && category['status'] == 'completed') {
        total += category['amount'] as double;
      }
    }
    return total;
  }

  double get progressPercentage =>
      (totalSpent / widget.monthlyLimit).clamp(0.0, 1.0);
  bool get isLimitExceeded => totalSpent > widget.monthlyLimit;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkAndShowLimitWarning();
    });
  }

  void _checkAndShowLimitWarning() {
    if (isLimitExceeded && !hasShownLimitWarning) {
      hasShownLimitWarning = true;
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Limit Exceeded',
              style: GoogleFonts.montserrat(
                  fontWeight: FontWeight.bold, color: Color(0xFF318F62))),
          content: Text('You have exceeded this month\'s limit.',
              style: GoogleFonts.nunito()),
          backgroundColor: Color(0xFFF5F2EA),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK',
                  style: GoogleFonts.roboto(
                      fontWeight: FontWeight.bold, color: Color(0xFF318F62))),
            ),
          ],
        ),
      );
    }
  }

  void _showDeleteConfirmationDialog(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Category',
            style: GoogleFonts.montserrat(
                fontWeight: FontWeight.bold, color: Color(0xFF318F62))),
        content: Text('Are you sure you want to delete this category?',
            style: GoogleFonts.nunito()),
        backgroundColor: Color(0xFFF5F2EA),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel',
                  style: GoogleFonts.roboto(color: Colors.grey.shade700))),
          TextButton(
              onPressed: () {
                setState(() => expenseCategories.removeAt(index));
                Navigator.pop(context);
              },
              child: Text('Delete',
                  style: GoogleFonts.roboto(
                      color: Colors.red, fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  void _editCategory(int index) async {
    final category = expenseCategories[index];
    final result = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => AddCategoryPage(
                  initialName: category['name'],
                  initialAmount: category['amount'],
                  initialCategory: _getCategoryFromIcon(category['icon']),
                )));
    if (result != null) {
      setState(() {
        expenseCategories[index] = {
          'name': result['name'].toString().toUpperCase(),
          'amount': result['amount'],
          'icon': _getIconForCategory(result['category']),
          'status': 'completed',
        };
        hasShownLimitWarning = false;
        _checkAndShowLimitWarning();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F2EA),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(16),
              padding: EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Color(0xFF318F62),
                borderRadius: BorderRadius.circular(32),
              ),
              child: Column(
                children: [
                  Text(widget.selectedMonth,
                      style: GoogleFonts.montserrat(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFF8DF9D))),
                  SizedBox(height: 8),
                  Text('Limit for this month',
                      style: GoogleFonts.nunito(
                          fontSize: 16, color: Color(0xFFF8DF9D))),
                  SizedBox(height: 8),
                  Text('₱ ${totalSpent.toStringAsFixed(0)}',
                      style: GoogleFonts.montserrat(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFF8DF9D))),
                  SizedBox(height: 16),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: progressPercentage,
                      minHeight: 16,
                      backgroundColor: Color(0xFFF8DF9D).withOpacity(0.3),
                      valueColor: AlwaysStoppedAnimation(Color(0xFFF8DF9D)),
                    ),
                  ),
                  SizedBox(height: 8),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                          '${totalSpent.toStringAsFixed(0)}/${widget.monthlyLimit.toStringAsFixed(0)}',
                          style: GoogleFonts.roboto(
                              fontSize: 14, color: Color(0xFFF8DF9D)))),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => SummaryWheel(
                                categories: expenseCategories,
                                totalSpent: totalSpent,
                                monthlyLimit: widget.monthlyLimit))),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFFF8DF9D),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(24)),
                        padding:
                            EdgeInsets.symmetric(horizontal: 32, vertical: 12)),
                    child: Text('SUMMARY',
                        style: GoogleFonts.roboto(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF318F62))),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('EXPENSES',
                      style: GoogleFonts.montserrat(
                          fontSize: 24, fontWeight: FontWeight.w500)),
                  GestureDetector(
                    onTap: () async {
                      final result = await Navigator.push(context,
                          MaterialPageRoute(builder: (_) => AddCategoryPage()));
                      if (result != null) {
                        setState(() {
                          expenseCategories.add({
                            'name': result['name'].toString().toUpperCase(),
                            'amount': result['amount'],
                            'icon': _getIconForCategory(result['category']),
                            'status': 'completed',
                          });
                          hasShownLimitWarning = false;
                          _checkAndShowLimitWarning();
                        });
                      }
                    },
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                          border:
                              Border.all(color: Colors.grey.shade400, width: 2),
                          shape: BoxShape.circle),
                      child: Icon(Icons.add, size: 28),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: expenseCategories.isEmpty
                  ? Center(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                          Icon(Icons.add_circle_outline, size: 64),
                          SizedBox(height: 16),
                          Text('No expenses yet',
                              style: GoogleFonts.nunito(
                                  fontSize: 18, color: Colors.grey.shade600)),
                          SizedBox(height: 8),
                          Text('Tap the + button to add your first expense',
                              style: GoogleFonts.nunito(
                                  fontSize: 14, color: Colors.grey.shade500),
                              textAlign: TextAlign.center),
                        ]))
                  : ListView.builder(
                      itemCount: expenseCategories.length,
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      itemBuilder: (context, index) {
                        final category = expenseCategories[index];
                        return Dismissible(
                          key: Key(index.toString()),
                          background: Container(
                              color: Colors.red,
                              alignment: Alignment.centerRight,
                              padding: EdgeInsets.only(right: 20),
                              child: Icon(Icons.delete, color: Colors.white)),
                          direction: DismissDirection.endToStart,
                          confirmDismiss: (_) async {
                            _showDeleteConfirmationDialog(index);
                            return false;
                          },
                          child: Container(
                            margin: EdgeInsets.only(bottom: 8),
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 12),
                            decoration: BoxDecoration(
                                color: Color(0xFFCADFFF),
                                borderRadius: BorderRadius.circular(12)),
                            child: Row(
                              children: [
                                Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(8)),
                                    child: Icon(category['icon'],
                                        color: Colors.black)),
                                SizedBox(width: 16),
                                Expanded(
                                    child: Text(category['name'],
                                        style: GoogleFonts.roboto(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500),
                                        overflow: TextOverflow.ellipsis)),
                                SizedBox(width: 8),
                                category['status'] == 'pending'
                                    ? ElevatedButton(
                                        onPressed: () {
                                          setState(() {
                                            category['status'] = 'completed';
                                            category['amount'] = 0.0;
                                            hasShownLimitWarning = false;
                                            _checkAndShowLimitWarning();
                                          });
                                        },
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor: Color(0xFFF8DF9D),
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(24)),
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 24, vertical: 8)),
                                        child: Text('DONE',
                                            style: GoogleFonts.roboto(
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.black87)),
                                      )
                                    : Text(
                                        '₱${(category['amount'] as double).toStringAsFixed(2)}',
                                        style: GoogleFonts.roboto(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500)),
                                IconButton(
                                    icon: Icon(Icons.edit,
                                        color: Color(0xFF318F62), size: 20),
                                    onPressed: () => _editCategory(index)),
                                IconButton(
                                    icon: Icon(Icons.delete,
                                        color: Colors.red, size: 20),
                                    onPressed: () =>
                                        _showDeleteConfirmationDialog(index)),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            _buildCustomNavBar(context),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomNavBar(BuildContext context) {
    return SizedBox(
      height: 80,
      child: Stack(
        children: [
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 70,
              decoration: BoxDecoration(
                color: Color(0xFFF8DF9D),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30)),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: Offset(0, -5))
                ],
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: _getSelectedPosition(),
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: Color(0xFFF8DF9D),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: Offset(0, -2))
                ],
              ),
              child: Center(child: _getIconForIndex(_selectedIndex, true)),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: SizedBox(
              height: 70,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildNavItem(0, Icons.home),
                  _buildNavItem(1, Icons.book),
                  _buildNavItem(2, Icons.attach_money),
                  _buildNavItem(3, Icons.settings),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem(int index, IconData iconData) {
    return IconButton(
      icon: Icon(iconData,
          color: _selectedIndex == index ? Colors.white : Colors.black),
      onPressed: () {
        setState(() => _selectedIndex = index);
      },
    );
  }

  double _getSelectedPosition() {
    double screenWidth = MediaQuery.of(context).size.width;
    switch (_selectedIndex) {
      case 0:
        return screenWidth * 0.1;
      case 1:
        return screenWidth * 0.35;
      case 2:
        return screenWidth * 0.6;
      case 3:
        return screenWidth * 0.85;
      default:
        return screenWidth * 0.1;
    }
  }

  Icon _getIconForIndex(int index, bool isSelected) {
    Color color = isSelected ? Colors.white : Colors.black;
    switch (index) {
      case 0:
        return Icon(Icons.home, color: color);
      case 1:
        return Icon(Icons.book, color: color);
      case 2:
        return Icon(Icons.attach_money, color: color);
      case 3:
        return Icon(Icons.settings, color: color);
      default:
        return Icon(Icons.home, color: color);
    }
  }

  IconData _getIconForCategory(String category) {
    switch (category) {
      case 'Transportation':
        return Icons.directions_car_outlined;
      case 'Clothing':
        return Icons.shopping_bag_outlined;
      case 'Rent':
        return Icons.home_outlined;
      case 'Shopping':
        return Icons.shopping_cart_outlined;
      case 'Food':
        return Icons.fastfood_outlined;
      case 'Entertainment':
        return Icons.movie_outlined;
      case 'Utilities':
        return Icons.lightbulb_outline;
      default:
        return Icons.more_horiz;
    }
  }

  String _getCategoryFromIcon(IconData icon) {
    if (icon == Icons.directions_car_outlined) return 'Transportation';
    if (icon == Icons.shopping_bag_outlined) return 'Clothing';
    if (icon == Icons.home_outlined) return 'Rent';
    if (icon == Icons.shopping_cart_outlined) return 'Shopping';
    if (icon == Icons.fastfood_outlined) return 'Food';
    if (icon == Icons.movie_outlined) return 'Entertainment';
    if (icon == Icons.lightbulb_outline) return 'Utilities';
    return 'Other';
  }
}
