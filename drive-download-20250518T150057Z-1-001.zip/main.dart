import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'set_limit_page.dart';

void main() {
  runApp(const TrackademyApp());
}

class TrackademyApp extends StatelessWidget {
  const TrackademyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Trackademy',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF318F62),
        scaffoldBackgroundColor: const Color(0xFFF5F2EA),
        textTheme: TextTheme(
          displayLarge: GoogleFonts.montserrat(fontWeight: FontWeight.bold),
          displayMedium: GoogleFonts.montserrat(fontWeight: FontWeight.bold),
          displaySmall: GoogleFonts.montserrat(fontWeight: FontWeight.bold),
          headlineLarge: GoogleFonts.montserrat(fontWeight: FontWeight.bold),
          headlineMedium: GoogleFonts.montserrat(fontWeight: FontWeight.bold),
          headlineSmall: GoogleFonts.montserrat(),
          titleLarge: GoogleFonts.roboto(fontWeight: FontWeight.bold),
          titleMedium: GoogleFonts.roboto(),
          titleSmall: GoogleFonts.roboto(),
          bodyLarge: GoogleFonts.nunito(),
          bodyMedium: GoogleFonts.nunito(),
          bodySmall: GoogleFonts.nunito(),
        ),
      ),
      home: const SetLimitPage(),
    );
  }
}
