import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:math';

class SummaryWheel extends StatefulWidget {
  final List<Map<String, dynamic>> categories;
  final double totalSpent;
  final double monthlyLimit;

  const SummaryWheel({
    Key? key,
    required this.categories,
    required this.totalSpent,
    required this.monthlyLimit,
  }) : super(key: key);

  @override
  State<SummaryWheel> createState() => _SummaryWheelState();
}

class _SummaryWheelState extends State<SummaryWheel> {
  int _selectedIndex = 2;

  final List<Color> categoryColors = [
    Color(0xFF4ECDC4),
    Color(0xFF5B9BD5),
    Color(0xFFA2D1FA),
    Color(0xFF7BAAF7),
    Color(0xFF4285F4),
    Color(0xff44a5d5),
    Color(0xff0c6aa2),
    Color(0xff24415d),
    Color(0xff849cb3),
    Color(0xff78b7f0),
    Color(0xff4a9ebf),
    Color(0xff08abeb),
    Color(0xff2555da),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F2EA),
      body: SafeArea(
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  margin: EdgeInsets.all(16),
                  padding: EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Color(0xFF318F62),
                    borderRadius: BorderRadius.circular(32),
                  ),
                  child: Column(
                    children: [
                      SizedBox(height: 10),
                      Text(
                        'JANUARY',
                        style: GoogleFonts.montserrat(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFF8DF9D),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Limit for this month',
                        style: GoogleFonts.nunito(
                          fontSize: 16,
                          color: Color(0xFFF8DF9D),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        '₱ ${widget.totalSpent.toStringAsFixed(0)}',
                        style: GoogleFonts.montserrat(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFF8DF9D),
                        ),
                      ),
                      SizedBox(height: 16),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: (widget.totalSpent / widget.monthlyLimit)
                              .clamp(0.0, 1.0),
                          minHeight: 16,
                          backgroundColor: Color(0xFFF8DF9D).withOpacity(0.3),
                          valueColor: AlwaysStoppedAnimation(Color(0xFFF8DF9D)),
                        ),
                      ),
                      SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${widget.totalSpent.toStringAsFixed(0)}/${widget.monthlyLimit.toStringAsFixed(0)}',
                          style: GoogleFonts.roboto(
                            fontSize: 14,
                            color: Color(0xFFF8DF9D),
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                    ],
                  ),
                ),
                Positioned(
                  left: 18,
                  top: 18,
                  child: IconButton(
                    icon: Icon(Icons.arrow_back, color: Color(0xFFF8DF9D)),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
              ],
            ),
            Expanded(
              child: Column(
                children: [
                  Expanded(
                    flex: 3,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CustomPaint(
                          size: Size(280, 280),
                          painter: WheelChartPainter(
                            categories: widget.categories,
                            totalSpent: widget.totalSpent,
                            colors: categoryColors,
                          ),
                        ),
                        Container(
                          width: 120,
                          height: 120,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white,
                          ),
                          child: ClipOval(
                            child: Image.asset('assets/junior_1.png',
                                fit: BoxFit.cover),
                          ),
                        ),
                        ..._buildCategoryIcons(),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 24.0),
                      child: _buildCategoryLabels(),
                    ),
                  ),
                ],
              ),
            ),
            _buildCustomNavBar(context),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildCategoryIcons() {
    final List<Widget> icons = [];
    final int categoryCount = widget.categories.length;
    if (categoryCount == 0) return icons;
    const double radius = 140.0;
    for (int i = 0; i < categoryCount; i++) {
      final category = widget.categories[i];
      if (category['status'] != 'completed' || category['amount'] == 0)
        continue;
      final double angle = 2 * pi * i / categoryCount;
      final double x = radius * cos(angle);
      final double y = radius * sin(angle);
    }
    return icons;
  }

  Widget _buildCategoryLabels() {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 3,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10),
      itemCount: widget.categories.length,
      itemBuilder: (context, index) {
        final category = widget.categories[index];
        final color = categoryColors[index % categoryColors.length];
        final amount = category['amount'] ?? 0.0;
        final percentage = widget.totalSpent > 0
            ? (amount / widget.totalSpent * 100).toStringAsFixed(1)
            : '0.0';
        return Row(
          children: [
            Container(
                width: 16,
                height: 16,
                decoration:
                    BoxDecoration(color: color, shape: BoxShape.circle)),
            SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(category['name'].toString(),
                      style: GoogleFonts.roboto(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87),
                      overflow: TextOverflow.ellipsis),
                  Text('₱${amount.toStringAsFixed(2)} (${percentage}%)',
                      style: GoogleFonts.roboto(
                          fontSize: 11, color: Colors.black54)),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildCustomNavBar(BuildContext context) {
    return SizedBox(
      height: 80,
      child: Stack(
        children: [
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 70,
              decoration: BoxDecoration(
                color: Color(0xFFF8DF9D),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30)),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: Offset(0, -5))
                ],
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: _getSelectedPosition(),
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: Color(0xFFF8DF9D),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: Offset(0, -2))
                ],
              ),
              child: Center(child: _getIconForIndex(_selectedIndex, true)),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: SizedBox(
              height: 70,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildNavItem(0, Icons.home),
                  _buildNavItem(1, Icons.book),
                  _buildNavItem(2, Icons.attach_money),
                  _buildNavItem(3, Icons.settings),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem(int index, IconData iconData) {
    return IconButton(
      icon: Icon(iconData,
          color: _selectedIndex == index ? Colors.white : Colors.black),
      onPressed: () {
        setState(() => _selectedIndex = index);
      },
    );
  }

  double _getSelectedPosition() {
    double screenWidth = MediaQuery.of(context).size.width;
    switch (_selectedIndex) {
      case 0:
        return screenWidth * 0.1;
      case 1:
        return screenWidth * 0.35;
      case 2:
        return screenWidth * 0.6;
      case 3:
        return screenWidth * 0.85;
      default:
        return screenWidth * 0.1;
    }
  }

  Icon _getIconForIndex(int index, bool isSelected) {
    Color color = isSelected ? Colors.white : Colors.black;
    switch (index) {
      case 0:
        return Icon(Icons.home, color: color);
      case 1:
        return Icon(Icons.book, color: color);
      case 2:
        return Icon(Icons.attach_money, color: color);
      case 3:
        return Icon(Icons.settings, color: color);
      default:
        return Icon(Icons.home, color: color);
    }
  }
}

class WheelChartPainter extends CustomPainter {
  final List<Map<String, dynamic>> categories;
  final double totalSpent;
  final List<Color> colors;

  WheelChartPainter(
      {required this.categories,
      required this.totalSpent,
      required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    final innerRadius = radius * 0.6;
    if (totalSpent <= 0) {
      final paint = Paint()
        ..color = Colors.grey.shade300
        ..style = PaintingStyle.stroke
        ..strokeWidth = radius - innerRadius;
      canvas.drawCircle(center, (radius + innerRadius) / 2, paint);
      return;
    }
    double startAngle = -pi / 2;
    for (int i = 0; i < categories.length; i++) {
      final category = categories[i];
      final amount = category['amount'] ?? 0.0;
      if (amount <= 0 || category['status'] != 'completed') continue;
      final sweepAngle = 2 * pi * (amount / totalSpent);
      final color = colors[i % colors.length];
      final paint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = radius - innerRadius
        ..strokeCap = StrokeCap.butt;
      canvas.drawArc(
          Rect.fromCircle(center: center, radius: (radius + innerRadius) / 2),
          startAngle,
          sweepAngle,
          false,
          paint);
      startAngle += sweepAngle;
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
