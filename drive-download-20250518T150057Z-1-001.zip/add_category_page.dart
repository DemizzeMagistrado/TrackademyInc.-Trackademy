import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class AddCategoryPage extends StatefulWidget {
  final String? initialName;
  final double? initialAmount;
  final String? initialCategory;

  const AddCategoryPage({
    Key? key,
    this.initialName,
    this.initialAmount,
    this.initialCategory,
  }) : super(key: key);

  @override
  _AddCategoryPageState createState() => _AddCategoryPageState();
}

class _AddCategoryPageState extends State<AddCategoryPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _amountController;
  late String _selectedCategory;

  // Predefined categories with their respective icons
  final Map<String, IconData> categories = {
    'Transportation': Icons.directions_car_outlined,
    'Clothing': Icons.shopping_bag_outlined,
    'Rent': Icons.home_outlined,
    'Shopping': Icons.shopping_cart_outlined,
    'Food': Icons.fastfood_outlined,
    'Entertainment': Icons.movie_outlined,
    'Utilities': Icons.lightbulb_outline,
    'Other': Icons.more_horiz,
  };

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.initialName ?? '');
    _amountController = TextEditingController(
        text: widget.initialAmount != null
            ? widget.initialAmount.toString()
            : '');
    _selectedCategory = widget.initialCategory ?? 'Transportation';
  }

  @override
  void dispose() {
    _nameController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isEditing = widget.initialName != null;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F2EA),
      appBar: AppBar(
        backgroundColor: const Color(0xFF318F62),
        title: Text(
          isEditing ? 'Edit Category' : 'Add New Category',
          style: GoogleFonts.montserrat(
            color: const Color(0xFFF8DF9D),
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFFF8DF9D)),
          onPressed: () => Navigator.pop(context),
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Select Category',
                  style: GoogleFonts.montserrat(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF4B4B4A),
                  ),
                ),
                const SizedBox(height: 16),

                // Category selection grid
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    childAspectRatio: 1,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: categories.length,
                  itemBuilder: (context, index) {
                    final category = categories.keys.elementAt(index);
                    final icon = categories[category];
                    final isSelected = _selectedCategory == category;

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedCategory = category;
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: isSelected
                              ? const Color(0xFFCADFFF)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isSelected
                                ? const Color(0xFF318F62)
                                : Colors.grey.shade300,
                            width: 2,
                          ),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              icon,
                              size: 28,
                              color: isSelected
                                  ? const Color(0xFF318F62)
                                  : Colors.grey,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              category,
                              style: GoogleFonts.roboto(
                                fontSize: 12,
                                color: isSelected
                                    ? const Color(0xFF318F62)
                                    : Colors.grey,
                                fontWeight: isSelected
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                              ),
                              textAlign: TextAlign.center,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 24),

                // Custom name field
                Text(
                  'Custom Name (Optional)',
                  style: GoogleFonts.montserrat(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF4B4B4A),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFCADFFF),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(
                      hintText: 'Enter custom name (optional)',
                      border: InputBorder.none,
                      hintStyle: GoogleFonts.nunito(
                        color: Colors.grey,
                      ),
                    ),
                    style: GoogleFonts.nunito(
                      color: const Color(0xFF4B4B4A),
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                // Amount field
                Text(
                  'Amount (₱)',
                  style: GoogleFonts.montserrat(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF4B4B4A),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFCADFFF),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: TextFormField(
                    controller: _amountController,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(
                          RegExp(r'^\d+\.?\d{0,2}')),
                    ],
                    decoration: InputDecoration(
                      hintText: 'Enter amount',
                      border: InputBorder.none,
                      hintStyle: GoogleFonts.nunito(
                        color: Colors.grey,
                      ),
                      prefixText: '₱ ',
                      prefixStyle: GoogleFonts.roboto(
                        color: const Color(0xFF4B4B4A),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter an amount';
                      }
                      return null;
                    },
                    style: GoogleFonts.nunito(
                      color: const Color(0xFF4B4B4A),
                    ),
                  ),
                ),

                const SizedBox(height: 40),

                // Add/Save button
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        // Create the expense category object
                        final categoryData = {
                          'name': _nameController.text.isNotEmpty
                              ? _nameController.text
                              : _selectedCategory,
                          'amount': double.parse(_amountController.text),
                          'category': _selectedCategory,
                        };

                        // Return to previous screen with the category data
                        Navigator.pop(context, categoryData);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF8DF9D),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(28),
                      ),
                    ),
                    child: Text(
                      isEditing ? 'SAVE CHANGES' : 'ADD EXPENSE',
                      style: GoogleFonts.roboto(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: const Color(0xFF318F62),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
